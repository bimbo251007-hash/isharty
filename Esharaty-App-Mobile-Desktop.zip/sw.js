"use strict";
// الكاش للعمل بدون إنترنت فقط؛ التحديثات تُجلب تلقائيًا من الإنترنت أولًا
const CACHE = "esharaty-v1";
const FILES = [
  "./",
  "index.html",
  "style.css",
  "app.js",
  "lessons.js",
  "manifest.webmanifest",
  "assets/afraid.webp",
  "assets/arabic.woff",
  "assets/book.webp",
  "assets/cold.webp",
  "assets/doctor.webp",
  "assets/font-license.txt",
  "assets/food.webp",
  "assets/friend.webp",
  "assets/happy.webp",
  "assets/help.webp",
  "assets/icon-192.png",
  "assets/icon-512.png",
  "assets/icon.png",
  "assets/pain.webp",
  "assets/pen.webp",
  "assets/play.webp",
  "assets/qr-afraid.png",
  "assets/qr-book.png",
  "assets/qr-cold.png",
  "assets/qr-doctor.png",
  "assets/qr-food.png",
  "assets/qr-friend.png",
  "assets/qr-happy.png",
  "assets/qr-help.png",
  "assets/qr-pain.png",
  "assets/qr-pen.png",
  "assets/qr-play.png",
  "assets/qr-sad.png",
  "assets/qr-school.png",
  "assets/qr-sleep.png",
  "assets/qr-soap.png",
  "assets/qr-sun.png",
  "assets/qr-toilet.png",
  "assets/qr-water.png",
  "assets/sad.webp",
  "assets/school.webp",
  "assets/sleep.webp",
  "assets/soap.webp",
  "assets/sun.webp",
  "assets/toilet.webp",
  "assets/water.webp"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener("fetch", event => {
  if (event.request.method !== "GET" || new URL(event.request.url).origin !== location.origin) return;
  // الإنترنت أولًا (دايمًا أحدث نسخة) ثم الكاش لو مفيش اتصال
  event.respondWith(
    fetch(event.request.url, { cache: "no-cache" })
      .then(res => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then(cache => cache.put(event.request, copy));
        }
        return res;
      })
      .catch(() => caches.match(event.request).then(hit => hit || caches.match("index.html")))
  );
});

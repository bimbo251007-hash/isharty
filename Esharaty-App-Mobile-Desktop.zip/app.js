"use strict";

const STORAGE_KEY = "esharaty-family-v1";
const main = document.querySelector("#content");
const header = document.querySelector("#header");
const notice = document.querySelector("#notice");
const byId = Object.fromEntries(lessons.map(lesson => [lesson.id, lesson]));
const ids = Object.keys(byId);
const modes = {
  quiz: { name:"اختار الإجابة", icon:"🎯", detail:"شوف الصورة واختار الكلمة اللي تناسبها." },
  match: { name:"وصّل الصورة بالكلمة", icon:"🧩", detail:"اضغط على صورة، وبعدها اضغط على الكلمة المطابقة." },
  situation: { name:"صورة لكل موقف", icon:"💡", detail:"اقرأ الموقف واختار الصورة اللي تعبّر عنه." },
};
const sections = [
  ["home","الرئيسية"], ["learn","التعلّم"], ["games","الألعاب"], ["communicate","التواصل"],
  ["specialist","لوحة الأخصائي"], ["cards","الكروت"], ["certificate","الشهادة"],
];
const levels = ["لم يُقيّم بعد", "يحتاج مساعدة", "في مرحلة التعلّم", "يعبّر باستقلالية"];
let storageAvailable = true;
function readState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (saved && Array.isArray(saved.children) && saved.children.length) return saved;
  } catch { storageAvailable = false; }
  return { parent:"", role:"الأم", children:[], active:"" };
}
let family = readState();
let communication = "";
let noticeTimeout;
let viewName = "";
let firstRoute = true;
const child = () => family.children.find(profile => profile.id === family.active) || family.children[0];
const number = value => new Intl.NumberFormat("ar-EG").format(value);
const safe = (value = "") => String(value).replace(/[&<>"']/g, character => (
  { "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[character]
));
function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(family));
  } catch {
    storageAvailable = false;
    toast("المتصفح منع الحفظ. تقدر تكمل اللعب خلال الزيارة الحالية.");
  }
}
function toast(message) {
  clearTimeout(noticeTimeout);
  notice.textContent = message;
  notice.hidden = false;
  noticeTimeout = setTimeout(() => { notice.hidden = true; }, 3300);
}
function navigate(route) {
  const next = "#" + route;
  if (location.hash === next) render();
  else location.hash = next;
}
function artwork(lesson, decorative = false) {
  return '<img src="assets/' + lesson.id + '.webp" alt="' + (decorative ? "" : lesson.alt) + '" width="506" height="506">';
}
function qr(lesson) {
  return '<a href="' + lesson.source + '" target="_blank" rel="noopener noreferrer" aria-label="افتح مرجع ' + lesson.name + '"><img class="qr" src="assets/qr-' + lesson.id + '.png" alt="رمز مسح مرجع ' + lesson.name + '" width="120" height="120"></a>';
}
function artStack() {
  return '<div class="art-stack" aria-hidden="true">' + artwork(byId.food,true) + artwork(byId.sleep,true) + artwork(byId.water,true) + '<span class="spark one">✦</span><span class="spark two">✦</span></div>';
}
function button(label, action, value = "", style = "") {
  return '<button type="button" class="btn ' + style + '" data-action="' + action + '" data-value="' + value + '">' + label + '</button>';
}
function link(label, route, style = "") {
  return '<a class="btn ' + style + '" href="#' + route + '">' + label + '</a>';
}
function intro(title, text) {
  return '<div class="intro"><h1>' + title + '</h1><p>' + text + '</p></div>';
}
function pageHeader(section, profile) {
  const nav = profile ? '<nav class="nav" aria-label="أقسام اللعبة">' + sections.map(([id,label]) =>
    '<a href="#' + id + '"' + (section === id ? ' aria-current="page"' : "") + '>' + label + '</a>').join("") + '</nav>' : "";
  const chip = profile ? '<button type="button" class="profile-chip" data-action="profiles" aria-label="تبديل الطفل أو تعديل بيانات الأسرة"><span>' + safe(profile.name) + '</span><span>⭐ ' + number(profile.stars) + '</span></button>' : "";
  header.innerHTML = '<div class="wrap top"><a class="brand" href="#home"><span class="logo" aria-hidden="true">✦</span> إشارتي</a>' + nav + chip + '</div>';
}
function childField(profile, index, removable) {
  return '<div class="field-row"><input name="child" autocomplete="off" aria-label="اسم الطفل ' + number(index + 1) + '" placeholder="اسم الطفل" maxlength="45" required value="' + safe(profile?.name) + '" data-id="' + safe(profile?.id) + '">' +
    (removable ? '<button type="button" class="remove" data-action="remove-child" aria-label="إزالة حقل الطفل">إزالة</button>' : '') + '</div>';
}
function welcome(edit = false) {
  const profiles = edit ? family.children : [null];
  return '<div class="welcome"><div class="welcome-art">' + artStack() +
    '<h2>أتعلّم وأعبّر</h2><p class="sub">أشوف الصورة، أفهم الكلمة، وأقول أنا محتاج إيه.</p></div>' +
    '<section class="welcome-form"><p class="eyebrow">لعبة تعليمية مصوّرة</p><h1>' + (edit ? "بيانات الأسرة" : "أهلًا بك في إشارتي!") + '</h1><p class="sub">' +
    (edit ? "عدّل الأسماء أو أضف طفلًا جديدًا." : "أضف بيانات ولي الأمر والأطفال علشان نبدأ.") + '</p>' +
    '<form id="family-form"><div class="fields"><div><label for="parent-name">اسم ولي الأمر</label><input id="parent-name" name="parent" autocomplete="off" maxlength="60" placeholder="الاسم الأول" required value="' + safe(edit ? family.parent : "") + '"></div>' +
    '<div><label for="parent-role">صلة القرابة</label><select id="parent-role" name="role">' + ["الأم","الأب","ولي أمر آخر"].map(role => '<option' + (role === family.role ? ' selected' : "") + '>' + role + '</option>').join("") +
    '</select></div></div><p class="label">أسماء الأطفال</p><div id="child-fields">' + profiles.map((profile,index) => childField(profile,index,false)).join("") + '</div>' +
    button("＋ إضافة طفل", "add-child", "", "outline") +
    '<p class="form-note">يكفي الاسم الأول أو اسم مستعار. الأسماء والتقدّم محفوظان في هذا المتصفح فقط.</p><p id="form-error" class="form-error" role="alert" hidden></p>' +
    '<div class="actions form-actions"><button type="submit" class="btn primary">' + (edit ? "حفظ بيانات الأسرة" : "ابدأ اللعبة") + '</button>' + (edit ? link("رجوع","specialist","outline") : "") + '</div></form></section></div>';
}
function home(profile) {
  const cards = [
    ["learn","📚","أتعلّم",number(ids.length) + " درس مصوّر عن احتياجاتي ومشاعري ويومي."],
    ["games","🎮","ألعب","ثلاث ألعاب صامتة أجمع فيها نقاطًا ونجومًا."],
    ["communicate","💬","أتواصل","أختار صورة وأعرض جملة تعبّر عن احتياجي."],
  ];
  return '<section class="hero"><div class="hero-copy"><p class="eyebrow">أهلًا يا <bdi>' + safe(profile.name) + '</bdi> 👋</p><h1>إشارتي <em>أتعلّم وأعبّر</em></h1>' +
    '<p class="sub">بالصور والكلمات، أقدر أقول أنا محتاج إيه.</p><div class="actions">' +
    link("ابدأ التعلّم","learn","primary") + link("العب الآن","games","white") + '</div></div>' +
    artStack() + '</section><div class="section-head"><h2>تحب تعمل إيه؟</h2></div><div class="row3">' +
    cards.map(([route,icon,title,detail]) => '<a href="#' + route + '" class="home-card"><span class="badge-icon" aria-hidden="true">' + icon +
    '</span><h3>' + title + '</h3><p>' + detail + '</p></a>').join("") +
    '</div><div class="section-head"><h2>للأسرة والأخصائي</h2></div><div class="shortcut">' +
    link("لوحة الأخصائي","specialist","outline") + link("الكروت للطباعة","cards","outline") + link("شهادة التشجيع","certificate","outline") + '</div>';
}
function lessonList(profile) {
  return intro("التعلّم", "اختار صورة علشان تعرف اسم الاحتياج والجملة اللي تعبّر عنه.") +
    '<div class="tiles">' + lessons.map(lesson => '<a class="tile" href="#lesson/' + lesson.id + '">' + artwork(lesson,true) +
    '<span class="tile-body"><strong>' + lesson.name + '</strong><small>' +
    (profile.learned.includes(lesson.id) ? '<span class="done">✓ تم التعلّم</span>' : "افتح الدرس") + '</small></span></a>').join("") + '</div>';
}
function lessonView(lesson, profile) {
  const position = ids.indexOf(lesson.id);
  const next = ids[position + 1];
  const learned = profile.learned.includes(lesson.id);
  return '<a class="back" href="#learn">كل الدروس</a><div class="panel lesson">' + artwork(lesson) +
    '<div><span class="pill">درس ' + number(position + 1) + ' من ' + number(ids.length) + '</span><h1>' + lesson.name + '</h1>' +
    '<p class="phrase">' + lesson.phrase + '</p><div class="actions">' +
    (learned ? '<span class="done">✓ تم التعلّم</span>' : button("✓ تمّ التعلّم","learned",lesson.id,"primary")) +
    link(next ? "الدرس التالي" : "كل الدروس", next ? "lesson/" + next : "learn", "outline") +
    '</div><div class="reference">' + qr(lesson) + '<div><strong>' + (lesson.referenceTitle || "مرجع لغة الإشارة") + '</strong><small>' +
    (lesson.referenceNote || "مدخل مصوّر للكلمة من القاموس الإشاري العربي للصم. راجع النموذج مع أخصائي لغة الإشارة المصرية قبل استخدامه في التدريب.") +
    '</small><a class="btn outline" href="' + lesson.source + '" target="_blank" rel="noopener noreferrer">' + (lesson.sourceLabel || "افتح مرجع الكلمة") + '</a></div></div></div></div>';
}
function communicate() {
  return intro("التواصل", "اختار صورة واعرض جملتك للي معاك.") +
    '<div class="panel comm-banner" role="status" aria-live="polite"><p id="communication-phrase" class="phrase">' +
    (byId[communication]?.phrase || "أنا محتاج…") + '</p></div><div class="tiles">' +
    lessons.map(lesson => '<button type="button" class="tile" data-action="say" data-value="' + lesson.id + '" aria-pressed="' +
    (communication === lesson.id) + '">' + artwork(lesson,true) + '<span class="tile-body"><strong>' + lesson.name + '</strong></span></button>').join("") + '</div>';
}
function gameList(profile) {
  return intro("الألعاب", "اختار لعبة واجمع النجوم. كل الألعاب بتشتغل من غير صوت.") +
    '<div class="game-menu">' + Object.entries(modes).map(([id,mode]) => '<a class="activity-card" href="#game/' + id + '"><span class="badge-icon" aria-hidden="true">' +
    mode.icon + '</span><h2>' + mode.name + '</h2><p>' + mode.detail + '</p><span class="btn">' +
    (profile.rounds[id] && !profile.rounds[id].finished ? "كمّل اللعب" : "ابدأ اللعب") + '</span></a>').join("") + '</div>';
}
function shuffled(items) {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}
function groupsOf(items, size) {
  return Array.from({length:Math.ceil(items.length / size)}, (_, index) => items.slice(index * size, (index + 1) * size));
}
function roundFor(mode, profile) {
  if (profile.rounds[mode]) return profile.rounds[mode];
  const order = shuffled(ids);
  const round = { order, index:0, correct:0, answered:"", finished:false };
  if (mode === "match") {
    round.wordGroups = groupsOf(order,3).map(group => shuffled(group));
    round.matched = [];
    round.selected = "";
    round.wrong = "";
    round.misses = 0;
  } else {
    round.options = order.map(id => shuffled([id, ...shuffled(ids.filter(other => other !== id)).slice(0,2)]));
  }
  profile.rounds[mode] = round;
  saveState();
  return round;
}
function points(round) {
  return round.correct * 10;
}
function stars(round) {
  return round.correct >= Math.ceil(round.order.length * 5 / 6) ? 3 : round.correct >= Math.ceil(round.order.length / 2) ? 2 : round.correct >= 1 ? 1 : 0;
}
function finishRound(mode, profile, round) {
  round.finished = true;
  profile.points += points(round);
  profile.stars += stars(round);
  profile.history.unshift({ mode, points:points(round), stars:stars(round), at:new Date().toISOString() });
  saveState();
}
function choice(id, action, body, status = "", disabled = false, pressed = null) {
  return '<button type="button" class="choice ' + status + '" data-action="' + action + '" data-value="' + id + '"' +
    (disabled ? ' disabled' : "") + (pressed === null ? "" : ' aria-pressed="' + pressed + '"') + '>' + body + '</button>';
}
function feedback(message, status = "") {
  return '<p class="feedback ' + status + '" role="status">' + message + '</p>';
}
function game(mode, profile) {
  const round = roundFor(mode, profile);
  const detail = modes[mode];
  const total = round.order.length;
  let body;
  if (round.finished) {
    const earned = stars(round);
    body = '<section class="panel result"><div class="reward" aria-hidden="true">' + (earned ? "⭐".repeat(earned) : "🌈") +
      '</div><h2>' + (earned ? "أحسنت يا <bdi>" + safe(profile.name) + "</bdi>!" : "المحاولة هي أول خطوة!") +
      '</h2><p class="phrase">' + number(points(round)) + ' نقطة · ' + number(earned) + ' نجوم</p><p>إجابات صحيحة: ' +
      number(round.correct) + ' من ' + number(total) + '</p><div class="actions">' +
      button("العب من جديد","replay",mode,"primary") + link("اختار لعبة تانية","games","outline") + '</div></section>';
  } else if (mode === "match") {
    const group = round.order.slice(round.index * 3, round.index * 3 + 3);
    const complete = group.every(id => round.matched.includes(id));
    const pictures = group.map(id => choice(id,"match-picture", artwork(byId[id]) +
      (round.matched.includes(id) ? '<small>✓ تمّت المطابقة</small>' : ""), round.matched.includes(id) ? "correct" : round.selected === id ? "selected" : "",
      round.matched.includes(id), round.selected === id)).join("");
    const words = round.wordGroups[round.index].map(id => choice(id,"match-word", byId[id].name,
      round.matched.includes(id) ? "correct" : round.wrong === id ? "wrong" : "", round.matched.includes(id))).join("");
    const message = complete ? feedback("✓ طابقت كل الصور في المجموعة!", "correct") :
      round.wrong ? feedback("✕ جرّب كلمة تانية للصورة دي.", "wrong") :
      round.selected ? feedback("اختار الكلمة المناسبة للصورة.") :
      round.matched.length ? feedback("✓ مطابقة صحيحة! اختار صورة تانية.", "correct") : feedback("ابدأ باختيار صورة.");
    body = '<section class="panel"><h2>طابق الصورة مع الكلمة</h2><p class="sub">كل زوج صحيح يضيف ١٠ نقاط.</p><div class="matching"><div aria-label="الصور">' +
      pictures + '</div><div aria-label="الكلمات">' + words + '</div></div>' + message +
      (complete ? '<div class="actions game-next">' + button(round.index === round.wordGroups.length - 1 ? "اعرض النتيجة" : "المجموعة التالية","next",mode,"primary") + '</div>' : "") + '</section>';
  } else {
    const id = round.order[round.index];
    const lesson = byId[id];
    const isQuiz = mode === "quiz";
    const options = round.options[round.index].map(option => choice(option,"answer",
      isQuiz ? byId[option].name : artwork(byId[option]),
      round.answered && option === id ? "correct" : option === round.answered ? "wrong" : "", Boolean(round.answered))).join("");
    const reply = round.answered ? (round.answered === id ? feedback("✓ صح! كسبت ١٠ نقاط.", "correct") :
      feedback("✕ الإجابة الصحيحة هي " + lesson.name + ".", "wrong")) : "";
    body = '<section class="panel"><div class="question"><h2>' + (isQuiz ? "الصورة دي بتعبّر عن إيه؟" : lesson.situation) +
      '</h2>' + (isQuiz ? artwork(lesson) : "") + '</div><div class="answers">' + options + '</div>' + reply +
      (round.answered ? '<div class="actions game-next">' + button(round.index === total - 1 ? "اعرض النتيجة" : "السؤال التالي","next",mode,"primary") + '</div>' : "") + '</section>';
  }
  const progress = round.finished ? total : mode === "match" ? round.matched.length : round.index + Number(Boolean(round.answered));
  return '<div class="game"><a class="back" href="#games">كل الألعاب</a><div class="game-top"><h1>' + detail.name +
    '</h1><span class="pill">⭐ ' + number(points(round)) + ' نقطة</span></div><div class="track" role="progressbar" aria-label="تقدّم الجولة" aria-valuenow="' +
    progress + '" aria-valuemin="0" aria-valuemax="' + total + '"><span style="width:' + (progress / total * 100) + '%"></span></div>' + body + '</div>';
}
function profilesView(profile) {
  return intro("اختار الطفل", "لكل طفل نقاطه وتقييمه ودروسه.") + '<div class="panel"><div class="actions">' +
    family.children.map(item => button(safe(item.name) + (item.id === profile.id ? " ✓" : ""), "select-child", item.id,
      item.id === profile.id ? "primary" : "outline")).join("") + '</div><div class="actions">' +
    link("تعديل بيانات الأسرة","family","outline") + link("الرئيسية","home","outline") + '</div></div>';
}
function specialist(profile) {
  const dates = new Intl.DateTimeFormat("ar-EG", { dateStyle:"medium" });
  return intro("لوحة الأخصائي", "تابع التقدّم وسجّل ملاحظاتك لكل طفل.") +
    '<div class="panel"><label class="label" for="active-child">الطفل</label><select id="active-child">' +
    family.children.map(item => '<option value="' + item.id + '"' + (profile.id === item.id ? " selected" : "") + '>' + safe(item.name) + '</option>').join("") +
    '</select><div class="actions">' + link("إضافة طفل أو تعديل بيانات الأسرة","family","outline") + '</div></div>' +
    '<div class="section-head"><h2>التقدّم</h2></div><div class="metrics">' +
    [[number(profile.learned.length) + "/" + number(ids.length),"الدروس"],[number(profile.points),"النقاط"],[number(profile.stars),"النجوم"]].map(([value,label]) =>
      '<div class="metric"><strong><bdi>' + value + '</bdi></strong><span>' + label + '</span></div>').join("") +
    '</div><div class="dashboard"><section class="panel"><h2>التقييم</h2><form id="evaluation"><label for="level">مستوى الطفل</label><select id="level" name="level">' +
    levels.map(level => '<option' + (level === profile.level ? " selected" : "") + '>' + level + '</option>').join("") +
    '</select><label for="evaluation-note">ملاحظات الأخصائي</label><textarea id="evaluation-note" name="note" maxlength="1000" placeholder="مثال: يختار صورة المياه بدون مساعدة.">' +
    safe(profile.note) + '</textarea><div class="actions"><button class="btn primary" type="submit">احفظ التقييم</button></div></form></section>' +
    '<section class="panel"><h2>آخر الجولات</h2>' +
    (profile.history.length ? '<ul class="history">' + profile.history.slice(0,10).map(item => '<li><div><strong>' + modes[item.mode].name +
      '</strong><p class="muted">' + dates.format(new Date(item.at)) + '</p></div><span>' + number(item.points) + ' نقطة · ⭐ ' + number(item.stars) + '</span></li>').join("") +
      '</ul>' : '<p class="sub">ابدأ لعبة علشان تظهر نتائجها هنا.</p>') +
    '<h3 class="section-head">الدروس المكتملة</h3><p class="muted">' + (profile.learned.length ? profile.learned.map(id => byId[id].name).join("، ") : "لسه مفيش دروس مكتملة.") + '</p></section></div>';
}
function cardsView() {
  return '<div class="no-print">' + intro("الكروت التعليمية", number(ids.length) + " بطاقة مصوّرة. اطبعها لاستخدامها في البيت أو الجلسة.") +
    button("🖨 طباعة الكروت","print","","primary") + '</div>' +
    groupsOf(lessons,6).map(group => '<div class="print-grid">' + group.map(lesson =>
      '<article class="print-card">' + artwork(lesson) + '<h2>' + lesson.name + '</h2><p>' + lesson.phrase + '</p><div class="print-meta">' +
      qr(lesson) + '<span>' + (lesson.verified ? "امسح الرمز لفتح نموذج الكلمة" : "مدخل مصوّر للكلمة · راجع الإشارة المصرية مع متخصص") +
      '</span></div></article>').join("") + '</div>').join("");
}
function certificate(profile) {
  const date = new Intl.DateTimeFormat("ar-EG", { dateStyle:"long" }).format(new Date());
  return '<div class="no-print">' + intro("شهادة التشجيع", "شهادة باسم الطفل والنجوم اللي جمعها.") +
    button("🖨 طباعة الشهادة","print","","primary") + '</div><article class="certificate"><p class="reward" aria-hidden="true">🏅</p><h1>شهادة تشجيع</h1><p>يسعد مشروع إشارتي بتقديم هذه الشهادة إلى</p><h2 class="child-name"><bdi>' +
    safe(profile.name) + '</bdi></h2><p>تقديرًا لمشاركته في أنشطة التعلّم والتعبير.</p><p class="pill">⭐ ' +
    number(profile.stars) + ' نجوم · ' + number(profile.points) + ' نقطة</p><p>' + date + '</p><p class="muted">إشارتي · أتعلّم وأعبّر</p></article>';
}
function render() {
  const raw = location.hash.slice(1);
  const [route, key] = raw.split("/");
  const profile = child();
  let view = profile ? (route || "home") : "welcome";
  const renderPage = {
    home:home, learn:lessonList, games:gameList, communicate,
    specialist, cards:cardsView, certificate, profiles:profilesView,
    family:() => welcome(true), welcome:() => welcome(),
    lesson:() => Object.hasOwn(byId,key) && lessonView(byId[key],profile),
    game:() => Object.hasOwn(modes,key) && game(key,profile),
  };
  if (!Object.hasOwn(renderPage,view) || (profile && view === "welcome")) view = "home";
  const routeChanged = viewName !== view + "/" + (key || "");
  viewName = view + "/" + (key || "");
  const navSection = ({lesson:"learn",game:"games",profiles:"specialist",family:"specialist"})[view] || view;
  const navScroll = header.querySelector(".nav")?.scrollLeft || 0;
  pageHeader(navSection,profile);
  const nav = header.querySelector(".nav");
  if (nav) nav.scrollLeft = navScroll;
  main.innerHTML = (storageAvailable ? "" : '<p class="storage-note no-print">الحفظ غير متاح في هذا المتصفح خلال الزيارة الحالية.</p>') +
    (renderPage[view](profile) || home(profile));
  if (routeChanged && !firstRoute) {
    window.scrollTo(0,0);
    main.focus({preventScroll:true});
  }
  firstRoute = false;
}
function profileRecord(name) {
  return { id:globalThis.crypto?.randomUUID?.() || "child-" + Date.now() + "-" + Math.random().toString(36).slice(2), name,
    learned:[], points:0, stars:0, rounds:{}, history:[], level:levels[0], note:"" };
}
main.addEventListener("submit", event => {
  if (event.target.id === "family-form") {
    event.preventDefault();
    const form = event.target;
    const data = new FormData(form);
    const parent = data.get("parent").trim();
    const fields = Array.from(form.querySelectorAll('[name="child"]'));
    const error = document.querySelector("#form-error");
    if (!parent || fields.some(field => !field.value.trim())) {
      error.textContent = "اكتب اسم ولي الأمر واسم كل طفل، أو احذف الحقول الزائدة.";
      error.hidden = false;
      return;
    }
    family.parent = parent;
    family.role = data.get("role");
    family.children = fields.map(field => {
      const name = field.value.trim();
      const existing = family.children.find(item => item.id === field.dataset.id);
      return existing ? { ...existing, name } : profileRecord(name);
    });
    family.active = child().id;
    saveState();
    const wasEditing = location.hash === "#family";
    navigate(wasEditing ? "specialist" : "home");
    if (wasEditing) toast("تم حفظ بيانات الأسرة.");
  }
  if (event.target.id === "evaluation") {
    event.preventDefault();
    const data = new FormData(event.target);
    const profile = child();
    profile.level = data.get("level");
    profile.note = data.get("note").trim();
    saveState();
    if (storageAvailable) toast("تم حفظ التقييم.");
  }
});
main.addEventListener("change", event => {
  if (event.target.id !== "active-child") return;
  family.active = event.target.value;
  communication = "";
  saveState();
  render();
  document.querySelector("#active-child").focus();
});
function handleGameAction(action, value) {
  const mode = location.hash.split("/")[1];
  if (!Object.hasOwn(modes,mode)) return;
  const profile = child();
  const round = profile.rounds[mode];
  if (action === "replay") {
    delete profile.rounds[mode];
    render();
    window.scrollTo(0,0);
    main.focus({preventScroll:true});
    return;
  }
  if (!round || round.finished) return;
  if (mode === "match") {
    const group = round.order.slice(round.index * 3, round.index * 3 + 3);
    if (action === "match-picture" && group.includes(value) && !round.matched.includes(value)) {
      round.selected = value;
      round.wrong = "";
    } else if (action === "match-word" && group.includes(value) && !round.matched.includes(value)) {
      if (!round.selected) {
        toast("اختار صورة من الأول.");
        return;
      }
      if (value !== round.selected) {
        round.wrong = value;
        round.misses++;
      } else {
        round.matched.push(value);
        round.selected = "";
        round.wrong = "";
        round.correct++;
      }
    } else if (action === "next" && group.every(id => round.matched.includes(id))) {
      if (round.index === round.wordGroups.length - 1) finishRound(mode,profile,round);
      else {
        round.index++;
        round.selected = "";
        round.wrong = "";
      }
    } else return;
  } else if (action === "answer" && !round.answered && round.options[round.index].includes(value)) {
    round.answered = value;
    if (value === round.order[round.index]) round.correct++;
  } else if (action === "next" && round.answered) {
    if (round.index === round.order.length - 1) finishRound(mode,profile,round);
    else {
      round.index++;
      round.answered = "";
    }
  } else return;
  saveState();
  render();
  if (action === "next") {
    window.scrollTo(0,0);
    main.querySelector("h1").setAttribute("tabindex","-1");
    main.querySelector("h1").focus({preventScroll:true});
  } else {
    const focus = main.querySelector('[data-action="next"]') ||
      Array.from(main.querySelectorAll("[data-action]")).find(item => item.dataset.action === action && item.dataset.value === value && !item.disabled);
    if (focus) focus.focus({preventScroll:true});
  }
}
document.addEventListener("click", event => {
  if (event.target.closest(".skip")) {
    event.preventDefault();
    main.focus();
    return;
  }
  const control = event.target.closest("button[data-action]");
  if (!control || control.disabled) return;
  const { action, value } = control.dataset;
  const profile = child();
  switch (action) {
    case "add-child": {
      const fields = document.querySelector("#child-fields");
      fields.insertAdjacentHTML("beforeend",childField(null,fields.children.length,true));
      fields.lastElementChild.querySelector("input").focus();
      break;
    }
    case "remove-child": {
      const fields = control.closest("#child-fields");
      control.closest(".field-row").remove();
      Array.from(fields.querySelectorAll("input")).forEach((field,i) => field.setAttribute("aria-label","اسم الطفل " + number(i + 1)));
      document.querySelector('[data-action="add-child"]').focus();
      break;
    }
    case "profiles":
      navigate("profiles");
      break;
    case "select-child":
      if (!family.children.some(item => item.id === value)) return;
      family.active = value;
      communication = "";
      saveState();
      navigate("home");
      break;
    case "learned":
      if (!profile.learned.includes(value) && ids.includes(value)) {
        profile.learned.push(value);
        saveState();
        render();
        if (storageAvailable) toast("برافو! اتسجّل الدرس.");
      }
      break;
    case "say":
      communication = value;
      document.querySelector("#communication-phrase").textContent = byId[value].phrase;
      main.querySelectorAll('[data-action="say"]').forEach(item => item.setAttribute("aria-pressed",String(item === control)));
      document.querySelector(".comm-banner").scrollIntoView({block:"nearest"});
      break;
    case "print":
      window.print();
      break;
    default:
      handleGameAction(action,value);
  }
});
window.addEventListener("hashchange", render);
render();

"use strict";

const lessons = [
  { id:"water", name:"المياه", phrase:"أنا عطشان، عايز أشرب مياه.", alt:"كوب به مياه", situation:"بعد اللعب في الشمس حسّيت بالعطش. تختار صورة إيه؟", source:"https://menasy.com/signs/water-05058/" },
  { id:"food", name:"الأكل", phrase:"أنا جعان، عايز آكل.", alt:"تفاحة وساندوتش", situation:"رجعت من المدرسة وبطنك بتقرقر من الجوع. تختار صورة إيه؟", source:"https://menasy.com/signs/eat-22001/" },
  { id:"sleep", name:"النوم", phrase:"أنا نعسان، عايز أنام.", alt:"طفلة نائمة في سريرها", situation:"بالليل بدأت تتثاوب وعينيك بتقفل. تختار صورة إيه؟", source:"https://menasy.com/signs/sleep-22003/" },
  { id:"help", name:"المساعدة", phrase:"محتاج مساعدة.", alt:"طفلان يحملان صندوقًا معًا", situation:"حاولت تفتح علبة لوحدك ومقدرتش. تختار صورة إيه؟", source:"https://menasy.com/signs/help-22023/" },
  { id:"pain", name:"الألم", phrase:"أنا تعبان، عندي ألم.", alt:"طفل يضع يديه على بطنه بسبب الألم", situation:"بطنك بتوجعك وعايز تقول لحد كبير. تختار صورة إيه؟", source:"https://menasy.com/signs/pain-11046/" },
  { id:"toilet", name:"الحمّام", phrase:"عايز أدخل الحمّام.", alt:"مرحاض داخل الحمّام", situation:"أنت في الفصل وعايز تروح للمرحاض. تختار صورة إيه؟", source:"https://menasy.com/signs/bathroom-03029/" },
  { id:"soap", name:"الصابون", phrase:"عايز صابون علشان أغسل إيدي.", alt:"قطعة صابون وفقاعات", situation:"إيدك اتوسخت وعايز حاجة تستخدمها مع المياه لتنضيفها. تختار إيه؟", source:"https://menasy.com/signs/soap-b1451/" },
  { id:"cold", name:"البرد", phrase:"أنا بردان، ممكن ألبس جاكيت؟", alt:"طفل بيرتعش من البرد ولابس كوفية", situation:"الجو ساقع وجسمك بيرتعش. تختار صورة إيه؟", source:"https://menasy.com/signs/cold-05051/" },
  { id:"sun", name:"الشمس", phrase:"الشمس قوية، عايز أقعد في الضل.", alt:"طفل تحت شمس ساطعة", situation:"النور القوي في السما مضايقك وعايز تقعد في الضل. تختار صورة إيه؟", source:"https://menasy.com/signs/sun-12002/" },
  { id:"book", name:"الكتاب", phrase:"عايز كتاب أقرأ فيه.", alt:"كتاب بنفسجي", situation:"عايز تقرأ قصة جديدة فيها صفحات وصور. تختار إيه؟", source:"https://menasy.com/signs/book-07015/" },
  { id:"pen", name:"القلم", phrase:"محتاج قلم علشان أكتب اسمي.", alt:"قلم أصفر", situation:"عايز تكتب اسمك على الورقة. تستخدم إيه؟", source:"https://menasy.com/signs/pen-b1981/", sourceLabel:"افتح مرجع «قلم حبر»" },
  { id:"happy", name:"الفرح", phrase:"أنا مبسوط!", alt:"طفل مبتسم", situation:"اتفرجت على حاجة حلوة وابتسامتك مالية وشّك. بتعبّر عن شعورك بإيه؟", source:"https://menasy.com/signs/happy-08015/" },
  { id:"sad", name:"الحزن", phrase:"أنا زعلان، ممكن تقعد جنبي؟", alt:"طفل زعلان ودمعة على خدّه", situation:"لعبتك المفضلة اتكسرت وحسّيت إنك عايز تعيّط. تختار صورة إيه؟", source:"https://menasy.com/signs/sad-08016/" },
  { id:"afraid", name:"الخوف", phrase:"أنا خايف، ممكن تفضل معايا؟", alt:"طفل خايف من سحابة رعد", situation:"شوفت برق مفاجئ واتخضّيت. تختار صورة إيه علشان تعبّر عن إحساسك؟", source:"https://menasy.com/signs/afraid-08014/" },
  { id:"doctor", name:"الدكتور", phrase:"ممكن أروح للدكتور؟", alt:"طبيبة لابسة بالطو ومعاها سماعة", situation:"محتاج حد متخصص يكشف عليك ويطمنك. تختار مين؟", source:"https://menasy.com/signs/doctor-17039/" },
  { id:"school", name:"المدرسة", phrase:"أنا جاهز أروح المدرسة.", alt:"مبنى مدرسة وشنطة", situation:"جهّزت شنطتك ورايح المكان اللي بتتعلم فيه مع زمايلك. تختار صورة إيه؟", source:"https://menasy.com/signs/school-07006/" },
  { id:"friend", name:"الصديق", phrase:"عايز أقعد جنب صاحبي.", alt:"طفلان صديقان واقفين جنب بعض", situation:"عايز تقعد جنب زميلك المفضل في الفسحة. تختار صورة إيه؟", source:"https://menasy.com/signs/friend-26001/" },
  { id:"play", name:"اللعب", phrase:"عايز ألعب شوية.", alt:"كرة ومكعبات ملوّنة للعب", situation:"قدامك وقت فاضي ونفسك تركّب مكعبات أو تجري ورا الكورة. تختار صورة إيه؟", source:"https://menasy.com/signs/playing-b2082/" },
];

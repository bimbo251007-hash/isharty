// ينسخ ملفات الموقع إلى مجلد www (يستخدمه Capacitor وElectron)
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const out = path.join(root, "www");
const items = ["index.html", "style.css", "app.js", "lessons.js", "sw.js", "manifest.webmanifest", "assets"];

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const item of items) {
  fs.cpSync(path.join(root, item), path.join(out, item), { recursive: true });
}
console.log("www ready:", items.length, "items");
